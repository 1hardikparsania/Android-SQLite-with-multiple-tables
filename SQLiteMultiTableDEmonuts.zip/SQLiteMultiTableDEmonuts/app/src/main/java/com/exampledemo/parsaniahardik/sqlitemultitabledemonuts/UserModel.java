package com.exampledemo.parsaniahardik.sqlitemultitabledemonuts;

import java.io.Serializable;

/**
 * Created by Parsania Hardik on 26-Apr-17.
 */
public class UserModel implements Serializable{

    private String name, hobby, city;
    private int id;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }
}
